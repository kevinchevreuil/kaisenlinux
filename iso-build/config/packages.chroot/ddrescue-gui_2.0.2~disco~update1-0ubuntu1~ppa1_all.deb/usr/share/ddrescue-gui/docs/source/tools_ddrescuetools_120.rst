Documentation for the ddrescue tools for ddrescue version 1.20 in the ddrescue tools package in the tools package (Tools/DDRescueTools/one_point_twenty.py)
***********************************************************************************************************************************************************

.. automodule:: ddrescue_gui.Tools.DDRescueTools.one_point_twenty
    :members:
