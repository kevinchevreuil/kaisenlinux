Documentation for the ddrescue tools for ddrescue version 1.14 in the ddrescue tools package in the tools package (Tools/DDRescueTools/one_point_forteen.py)
************************************************************************************************************************************************************

.. automodule:: ddrescue_gui.Tools.DDRescueTools.one_point_forteen
    :members:
