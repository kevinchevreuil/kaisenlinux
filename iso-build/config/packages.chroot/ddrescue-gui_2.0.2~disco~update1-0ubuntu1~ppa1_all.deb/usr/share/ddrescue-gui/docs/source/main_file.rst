Documentation for the main executable file (DDRescue_GUI.py)
************************************************************

.. automodule:: ddrescue_gui.DDRescue_GUI
    :members:
