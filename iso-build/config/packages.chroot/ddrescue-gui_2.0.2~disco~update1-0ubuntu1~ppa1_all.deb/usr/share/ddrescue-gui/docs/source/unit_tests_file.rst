Documentation for the unit tests runner file (tests.py)
*******************************************************

.. automodule:: ddrescue_gui.tests
    :members:
