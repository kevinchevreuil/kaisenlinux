Documentation for the decorators module in the ddrescue tools package in the tools package (Tools/DDRescueTools/decorators.py)
******************************************************************************************************************************

.. automodule:: ddrescue_gui.Tools.DDRescueTools.decorators
    :members:
