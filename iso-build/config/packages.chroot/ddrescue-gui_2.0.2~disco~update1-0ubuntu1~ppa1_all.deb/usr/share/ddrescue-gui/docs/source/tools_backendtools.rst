Documentation for the backend tools module in the tools package (Tools/tools.py)
********************************************************************************

.. automodule:: ddrescue_gui.Tools.tools
    :members:
