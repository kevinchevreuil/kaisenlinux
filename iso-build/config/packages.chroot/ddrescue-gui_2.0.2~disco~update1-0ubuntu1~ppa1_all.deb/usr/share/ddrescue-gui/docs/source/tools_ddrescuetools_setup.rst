Documentation for the setup module in the ddrescue tools package in the tools package (Tools/DDRescueTools/setup.py)
********************************************************************************************************************

.. automodule:: ddrescue_gui.Tools.DDRescueTools.setup
    :members:
