/*
 *  /MathJax/jax/output/HTML-CSS/fonts/TeX/Main/Bold/SpacingModLetters.js
 *  
 *  Copyright (c) 2012 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS["MathJax_Main-bold"],{710:[694,-520,575,126,448],711:[660,-515,575,130,444],713:[607,-540,575,80,494],714:[706,-503,575,236,460],715:[706,-503,575,114,338],728:[694,-500,575,102,472],729:[695,-525,575,202,372],730:[702,-536,575,160,414],732:[694,-552,575,96,478]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/Main/Bold/SpacingModLetters.js");

