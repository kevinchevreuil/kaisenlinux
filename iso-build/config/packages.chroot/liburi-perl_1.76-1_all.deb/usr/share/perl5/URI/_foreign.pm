package URI::_foreign;

use strict;
use warnings;

use parent 'URI::_generic';

our $VERSION = '1.76';

1;
