module Vim
  class AddonManager
    VERSION = '0.5.10'
  end
end
