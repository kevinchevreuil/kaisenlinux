.. cmake-module:: ../../Modules/FindLua.cmake
