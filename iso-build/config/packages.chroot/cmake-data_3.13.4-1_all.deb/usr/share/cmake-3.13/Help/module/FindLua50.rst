.. cmake-module:: ../../Modules/FindLua50.cmake
