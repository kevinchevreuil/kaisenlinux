#ifndef MPEG3VIDEOPROTOS_H
#define MPEG3VIDEOPROTOS_H

void mpeg3video_idct_conversion(short* block);
unsigned int mpeg3slice_showbits(mpeg3_slice_buffer_t *slice_buffer, int bits);
int mpeg3video_get_header(mpeg3video_t *video, int dont_repeat);
unsigned int mpeg3bits_next_startcode(mpeg3_bits_t* stream);
void mpeg3video_calc_dmv(mpeg3video_t *video, int DMV[][2], int *dmvector, 
		int mvx, int mvy);

void mpeg3video_motion_vector(mpeg3_slice_t *slice, mpeg3video_t *video, 
			      int *PMV, int *dmvector, 
			      int h_r_size, int v_r_size,
			      int dmv, int mvscale, 
			      int full_pel_vector);
int mpeg3video_motion_vectors(mpeg3_slice_t *slice, mpeg3video_t *video, 
			      int PMV[2][2][2], int dmvector[2], 
			      int mv_field_sel[2][2], int s, 
			      int mv_count, int mv_format, 
			      int h_r_size, int v_r_size, 
			      int dmv, int mvscale);
int mpeg3video_getslicehdr(mpeg3_slice_t *slice, mpeg3video_t *video);
int mpeg3video_get_macroblocks(mpeg3video_t *video, int framenum);
int mpeg3video_get_macroblock_address(mpeg3_slice_t *slice);
int mpeg3video_read_raw(mpeg3video_t *video,  unsigned char *output, 
			long *size, long max_size);
int mpeg3video_read_frame_backend(mpeg3video_t *video, int skip_bframes);
int mpeg3video_read_yuvframe(mpeg3video_t *video,  char *y_output,
			     char *u_output, char *v_output,
			     int in_x, int in_y, int in_w, int in_h);
int mpeg3video_read_yuvframe_ptr(mpeg3video_t *video, char **y_output,
				 char **u_output, char **v_output);

#endif
