__version__ = '1.1.2'
__VERSION__ = __version__
from .workbook import Workbook
