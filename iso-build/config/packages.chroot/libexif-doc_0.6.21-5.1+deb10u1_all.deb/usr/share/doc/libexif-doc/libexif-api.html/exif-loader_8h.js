var exif_loader_8h =
[
    [ "ExifLoader", "exif-loader_8h.html#a2b96cbffaf0f92340a960f887026eced", null ],
    [ "exif_loader_get_buf", "exif-loader_8h.html#acb140c6f8bce84eb228592dcf202025d", null ],
    [ "exif_loader_get_data", "exif-loader_8h.html#abe54111cdaf5b0559a20e1e76c31a86c", null ],
    [ "exif_loader_log", "exif-loader_8h.html#a0779beeb15d0c56ae7442f4740f1baf7", null ],
    [ "exif_loader_new", "exif-loader_8h.html#a2d4278edbd89b5af3e5a4fe29b5e085c", null ],
    [ "exif_loader_new_mem", "exif-loader_8h.html#a95c8505132b2465c1078b0842285bfc7", null ],
    [ "exif_loader_ref", "exif-loader_8h.html#ac5e7a899a7499b56772b671add54fcde", null ],
    [ "exif_loader_reset", "exif-loader_8h.html#a080d8ebb5006c1306a3a798ff60253a5", null ],
    [ "exif_loader_unref", "exif-loader_8h.html#a7f4e3dfa0df969ac8c232327840ca105", null ],
    [ "exif_loader_write", "exif-loader_8h.html#ad1b65ac6288f5f28aa2b4b3d2bf3f56f", null ],
    [ "exif_loader_write_file", "exif-loader_8h.html#a613e86cc4f12d488fbd23fe97a0d30c5", null ]
];