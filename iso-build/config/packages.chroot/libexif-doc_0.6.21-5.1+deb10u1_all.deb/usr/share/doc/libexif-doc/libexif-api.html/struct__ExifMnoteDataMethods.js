var struct__ExifMnoteDataMethods =
[
    [ "count", "struct__ExifMnoteDataMethods.html#a1a2e67e1fec64777ff7851d2e6fd683c", null ],
    [ "free", "struct__ExifMnoteDataMethods.html#a517f154bc727e7f784cc6d0d1cb57462", null ],
    [ "get_description", "struct__ExifMnoteDataMethods.html#afdc5ebc5729967376c9f1131ff6b45ed", null ],
    [ "get_id", "struct__ExifMnoteDataMethods.html#ae965d64413040b869dd08cf1e0eda87b", null ],
    [ "get_name", "struct__ExifMnoteDataMethods.html#ae46f3acef957033cb98d15a760ca0435", null ],
    [ "get_title", "struct__ExifMnoteDataMethods.html#ac235dc391848c65a05217b6651b624d2", null ],
    [ "get_value", "struct__ExifMnoteDataMethods.html#acf319ce2c4d7d3837b901a460ed7068d", null ],
    [ "load", "struct__ExifMnoteDataMethods.html#a014ebfb395d75f21bbf3bb79cda400eb", null ],
    [ "save", "struct__ExifMnoteDataMethods.html#aff5107265ab7be79a34162f459bb744f", null ],
    [ "set_byte_order", "struct__ExifMnoteDataMethods.html#a3cc84bf78e93c0f88c89fc847d4da896", null ],
    [ "set_offset", "struct__ExifMnoteDataMethods.html#af6e4932aac7d5bf18620cefac439b964", null ]
];