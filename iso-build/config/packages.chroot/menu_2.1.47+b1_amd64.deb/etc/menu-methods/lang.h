#List of languages for multilingual menu

function sections_translations()="ar:ast:be:bg:bn:br:bs:ca:cs:da:de:dz:el:eo:es:et:eu:fi:fr:ga:gl:gu:he:hi:hr:hu:id:it:ja:ka:kk:km:ko:ku:lt:mk:ml:mr:nb:ne:nl:nn:pa:pl:pt:pt_BR:ro:ru:sk:sq:sv:ta:th:tl:tr:uk:vi:wo:zh_CN:zh_TW"
