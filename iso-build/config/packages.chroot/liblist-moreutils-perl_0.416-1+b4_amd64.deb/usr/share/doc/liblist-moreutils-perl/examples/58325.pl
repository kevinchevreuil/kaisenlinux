#!/usr/bin/perl 
#!/usr/bin/perl 
use strict;
use warnings;

# use Carp;

use List::MoreUtils qw(apply);
while(1) {
    apply {} (1);
}
